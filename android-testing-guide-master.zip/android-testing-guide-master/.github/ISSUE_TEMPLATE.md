<!-- Love android-testing-guide? Please consider supporting our collective:
👉  https://opencollective.com/android-testing-guide/donate -->